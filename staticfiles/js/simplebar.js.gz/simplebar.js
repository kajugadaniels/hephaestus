(function () {
    "use strict";

    var myElement = document.getElementById('sidebar-scroll');
    let verticalScroll =  new SimpleBar(myElement, {autoHide: true});

})();